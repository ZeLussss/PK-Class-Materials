# ---------------------------------------------------
# Imię i Nazwisko: Ksawery Zelek
# Temat: Odczyt i zapis z pliku - Plik CSV
# Data: 13.11.2025
# ---------------------------------------------------
import csv 
import json
import pickle
import os

'''
Przykładowe dane:
dane.csv:
Imie,Nazwisko,Wiek,Jezyki
Ksawery,Zelek,20,"['C++', 'Python']"
Anna,Kowalska,25,"['Java', 'Python']"
Jan,Nowak,30,"['JavaScript', 'PHP']"
Maria,Wiśniewska,28,"['Python', 'C#']"
Piotr,Zając,22,"['Assembly', 'C']"
Katarzyna,Mazur,27,"['Ruby', 'Python']"
Tomasz,Lewandowski,35,"['Go', 'Java']"
Magdalena,Wójcik,24,"['Swift', 'Kotlin']"
Paweł,Kamiński,29,"['Rust', 'Python']"
Joanna,Krawczyk,26,"['TypeScript', 'JavaScript']"
'''

# ---------------------------------------------------
#               WCZYTANIE DANYCH
# ---------------------------------------------------

def wczytajDane( nazwaPliku ):
    # Sprawdzenie rozszerzenia
    print( f"Nazwa pliku: { nazwaPliku }" )
    ext = os.path.splitext( nazwaPliku )[ 1 ].lower()
    print( ext )

    if ext == ".csv":
        return wczytaj_CSV( nazwaPliku )
    elif ext == ".json":
        return wczytaj_JSON( nazwaPliku )
    elif ext == ".pkl" or ext == ".pickle":
        return wczytaj_PICKLE( nazwaPliku )
    else:
        raise ValueError( "Nieobslugiwany format pliku" )
    
def wczytaj_CSV( nazwaPliku ):
    dane = []
    with open( nazwaPliku, newline="", encoding="utf-8" ) as f:
        reader = csv.reader( f )
        header = next( reader )
        for row in reader:
            dane.append( row )

    return { "header": header, "rows": dane }
    
def wczytaj_JSON( nazwaPliku ):
    with open( nazwaPliku, "r", encoding="utf-8" ) as f:
        dane = json.load( f )

    return dane

def wczytaj_PICKLE( nazwaPliku ):
    with open( nazwaPliku, "rb" ) as f:
        dane = pickle.load( f )
    
    return dane


def zapisz_csv(nazwa_pliku, dane):
    with open( nazwa_pliku, "w", newline="", encoding="utf-8" ) as f:
        writer = csv.writer( f )
        if "header" in dane:
            writer.writerow( dane[ "header" ] )
            writer.writerows( dane[ "rows" ] )
        else:
            # Jeśli dane są listą słowników
            keys = dane[ 0 ].keys()
            writer.writerow( keys )
            for row in dane:
                writer.writerow( row.values() )

def zapisz_json( nazwa_pliku, dane ):
    with open( nazwa_pliku, "w", encoding="utf-8" ) as f:
        json.dump( dane, f, indent=4, ensure_ascii=False )

def zapisz_pickle( nazwa_pliku, dane ):
    with open( nazwa_pliku, "wb" ) as f:
        pickle.dump( dane, f )

# ---------------------------------------------------------------
#                   GŁÓWNY PROGRAM
# ---------------------------------------------------------------

nazwa = input( "Podaj nazwę pliku (.csv, .json, .pkl): " )

try:
    wynik = wczytajDane( nazwa )
    print( "Dane z pliku:" )
    print( wynik )


# Tworzenie plików w trzech formatach
    zapisz_csv("dane.csv", wynik )
    zapisz_json("dane.json", wynik )
    zapisz_pickle("dane.pkl", wynik )

    print( "Pliki dane.csv, dane.json, dane.pkl zostały utworzone." )

except Exception as e:
    print( "Błąd:", e )