#include <iostream>

using namespace std;

// Algorytm liczący największą sumę 1D
long long find_max_1d( const long long* arr, int size )
{
    long long current_max = 0;
    long long global_max = 0;

    for( int i = 0; i < size; i++ )
    {
        current_max += arr[ i ];

        // Zerowanie sumy, jeśli jest ujemna
        if( current_max < 0 )
        {
            current_max = 0;
        }

        // Aktualizacja maksymalnej sumy
        if( current_max > global_max )
        {
            global_max = current_max;
        }
    }

    return global_max;
}

// Algorytm liczący największą sumę 2D
long long find_max_2d( int** matrix, int n, int m )
{
    long long max_sum = 0;

    // Tablica pomocnicza do sumowania kolumn
    long long* temp = new long long[ m ];

    for( int top = 0; top < n; top++ )
    {
        // Zerowanie tablicy pomocniczej
        for( int i = 0; i < m; i++ )
        {
            temp[ i ] = 0;
        }

        for( int bottom = top; bottom < n; bottom++ )
        {
            // Sumowanie wartości w kolumnach
            for( int col = 0; col < m; col++ )
            {
                temp[ col ] += matrix[ bottom ][ col ];
            }

            // Wywołanie algorytmu 1D
            long long current_sum = find_max_1d( temp, m );

            // Aktualizacja maksymalnej sumy 2D
            if( current_sum > max_sum )
            {
                max_sum = current_sum;
            }
        }
    }

    // Zwolnienie pamięci po tablicy pomocniczej
    delete[] temp;

    return max_sum;
}

// Funkcja tworząca tablicę 2D
int** create_matrix( int n, int m )
{
    int** matrix = new int*[ n ];

    for( int i = 0; i < n; i++ )
    {
        matrix[ i ] = new int[ m ];

        // Wczytywanie danych do tablicy
        for( int j = 0; j < m; j++ )
        {
            cin >> matrix[ i ][ j ];
        }
    }

    return matrix;
}

// Funkcja usuwająca tablicę 2D z pamięci
void delete_matrix( int** matrix, int n )
{
    for( int i = 0; i < n; i++ )
    {
        delete[] matrix[ i ];
    }

    delete[] matrix;
}

// Funckja przetwarzająca pojedyńczy zestaw danych 
void process_test_case()
{
    int n, m;

    // Wczytanie wymiarów tablicy
    if( !( cin >> n >> m ) )
    {
        return;
    }

    // Wywołanie funkcji tworzącej tablicę
    int** matrix = create_matrix( n, m );

    // Wywołanie algorytmu 2D
    long long wynik = find_max_2d( matrix, n, m );

    cout << wynik << "\n";

    delete_matrix( matrix, n );
}

// Funkcja main
int main()
{
    ios_base::sync_with_stdio( false );
    cin.tie( NULL );

    int z;

    // Wczytanie liczby zestawów danych
    if( !( cin >> z ) )
    {
        return 0;
    }

    while( z-- )
    {
        process_test_case();
    }

    return 0;
}